from django.contrib import admin
from user.models import CustomUser

admin.site.register(CustomUser)